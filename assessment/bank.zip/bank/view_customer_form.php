<h3>View Customer by Account Number</h3>
<form method="POST" action="process_customer.php?action=view">
    <label for="accountNumber">Account Number:</label><br>
    <input type="text" id="accountNumber" name="accountNumber" required><br><br>

    <input type="submit" value="View Customer">
</form>
