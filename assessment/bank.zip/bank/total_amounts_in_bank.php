<h3>total Customer by amounts in bank</h3>
<form method="POST" action="process_customer.php?action=view">
    <label for="totalamount">total amount :</label><br>
    <input type="text" id="totalamount" name="totalamount" required><br><br>

    <input type="submit" value="total amounts">
</form>
