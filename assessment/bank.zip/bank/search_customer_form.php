<h3>Search for Customer by Name</h3>
<form method="POST" action="process_customer.php?action=search">
    <label for="name">Customer Name:</label><br>
    <input type="text" id="name" name="name" required><br><br>

    <input type="submit" value="Search Customer">
</form>
